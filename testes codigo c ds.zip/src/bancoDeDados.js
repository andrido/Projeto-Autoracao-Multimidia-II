
let usuarios = {
    numeroUnico: 1,

    contas: [{
        id: 1,
        nome: "naninha",
        cpf: "00011122234",
        data_nascimento: "2021-03-15",
        telefone: "71999998888",
        email: "Ianebemlindinha@email.kom",
        senha: "12345",
        saldo: 0
    }],
    saques: [],
    depositos: [],
    transferencias: [],
}




module.exports = usuarios